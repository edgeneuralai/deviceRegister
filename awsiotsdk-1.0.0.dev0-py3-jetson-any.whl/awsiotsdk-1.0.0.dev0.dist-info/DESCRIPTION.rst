# Used the git code from online repo - https://github.com/aws/aws-iot-device-sdk-python-v2
# Modified this for our needs. 


